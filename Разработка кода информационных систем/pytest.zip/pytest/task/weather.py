import aiohttp


async def main():
    async with aiohttp.ClientSession() as session:
        async with session.get('https://weather.com') as response:
            response = await response.json()
            return response


async def read_timtable():
    response = await main()
    return response["weather"] == "sunny"
