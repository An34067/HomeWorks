from unittest.mock import AsyncMock, patch

import weather


async def test_read_timtable():
    with patch("weather.main", new_callable=AsyncMock, return_value={"weather": "sunny"}):
        result = await weather.read_timtable()

    assert result is True
