async def test_is_open(connection):
    assert connection.is_open is True
