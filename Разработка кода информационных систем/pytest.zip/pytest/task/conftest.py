import pytest


class AsyncConnection:
    async def connect(self):
        self.is_open = True

    async def close(self):
        self.is_open = False


@pytest.fixture
async def connection():
    conn = AsyncConnection()
    await conn.connect()
    yield conn
    await conn.close()
