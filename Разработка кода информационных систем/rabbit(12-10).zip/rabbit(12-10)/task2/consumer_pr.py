import pika

#1. Подключение
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

#2. Каналы
channel = connection.channel()

#3. Очередь(не обязательно. Принцип идемпотентности)
channel.queue_declare(queue="main", durable=True)

#4. Получение информации
#ch- channel - информация о канале
#method - методанные передачи
#properties - свойство сообщения
#body - сообщение
def call_func(ch, method, properties, body):
    print(f"Получил сообщение: {body.decode("utf-8")}")

channel.basic_consume(
    queue="main",
    on_message_callback=call_func, #функция при получении сообщения
    auto_ack=True  #автоподтверждение (Потом так делать не стоит)
)

print("Начал работу, жду что-то!")

channel.start_consuming()