import pika

#1. Подключение
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

#2. Каналы
channel = connection.channel()

#3. Очередь(не обязательно. Принцип идемпотентности)
channel.queue_declare(queue="main", durable=True)
channel.queue_declare(queue="save", durable=True)

#4. Сообщение и обменник
channel.basic_publish(
    exchange='', #По названию очереди
    routing_key="main",
    body="Event: login. User: A.D. Status:success"
)

channel.basic_publish(
    exchange='', #По названию очереди
    routing_key="save",
    body="Event: login. User: A.D. Status:success"
)

print("Отправка прошла успешно!")
connection.close()