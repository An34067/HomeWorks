import pika

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)
channel = connection.channel()

channel.queue_declare(queue="save", durable=True)

def call_func(ch, method, properties, body):
    message = body.decode("utf-8")
    print(f"Получил сообщение: {message}")
    
    with open("log.txt", "a", encoding="utf-8") as f: 
        f.write(message + "\n")  

channel.basic_consume(
    queue="save",
    on_message_callback=call_func, 
    auto_ack=True  
)

print("Начал работу, жду сообщения!")
channel.start_consuming()
