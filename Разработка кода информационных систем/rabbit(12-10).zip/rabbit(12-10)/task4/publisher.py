import pika

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)
channel = connection.channel()

#Fanout - широковещательный
#когда не существует обменника
channel.exchange_declare(exchange="event", exchange_type="fanout")

channel.basic_publish(
    exchange='event',
    routing_key="",
    body="Hello! Task is done!"
)

connection.close()