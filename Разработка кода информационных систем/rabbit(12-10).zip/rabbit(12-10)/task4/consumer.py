import pika

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)
channel = connection.channel()

def call_func(ch, method, properties, body):
    print(f"Получил сообщение: {body.decode("utf-8")}")

    ch.basic_ack(delivery_tag=method.delivery_tag)

result =channel.queue_declare(exclusive=True, auto_delete=True, queue="")
quenue_name = result.method.queue #название очереди

channel.queue_bind(exchange="event", queue=quenue_name)

channel.basic_consume(
    queue=quenue_name,
    on_message_callback=call_func, 
    auto_ack=False  
)

channel.start_consuming()
