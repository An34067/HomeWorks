import pika

#1. Подключение
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

#2. Каналы
channel = connection.channel()

#3. Очередь(не обязательно. Принцип идемпотентности)
channel.queue_declare(queue="hello", durable=True)
channel.queue_declare(queue="hello2", durable=True)

#4. Сообщение и обменник
channel.basic_publish(
    exchange='', #По названию очереди
    routing_key="hello",
    body="Hello world!"
)

channel.basic_publish(
    exchange='', #По названию очереди
    routing_key="hello2",
    body="Hello!"
)

print("Отправка прошла успешно!")
connection.close()