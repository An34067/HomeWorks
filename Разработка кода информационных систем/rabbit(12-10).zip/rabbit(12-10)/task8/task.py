from schedul import *
from datetime import *

#delay() - прямо сейчас
add.delay()

#beat_schedule - по расписанию

# через 5 секунд....
send_email.apply_async(coundown=5)

#через любое время, 48часов ...
send_email.apply_async(eta=datetime.now() + timedelta(hour=48))

