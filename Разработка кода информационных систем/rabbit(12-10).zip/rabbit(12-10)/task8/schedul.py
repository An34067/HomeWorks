from celery import Celery
from time import sleep
from datetime import datetime, timedelta
from celery.schedules import crontab


app = Celery(
    "Celery_app",
    broker="amqp://guest:guest@localhost//", #URL
    backend="db+sqlite:///result.sqlite3" #URI
)
#Базовые настройки
app.conf.update(
    timezone="UTC",
    time_track_started=True, #Принята, в работе, ожидает, обработана...
    task_acks_late=True

)
#Настройки beat scheduler

@app.task
def add(x, y):
    print(f"Sum {x + y}")


@app.task
def send_email():
    print(f"Send email")


# Настройки beat scheduler
app.conf.beat_schedule = {
    # Задача add будет запускаться каждый день в 13:30
    "schedule.add": {
        "task": "schedul.add",
        "schedule": crontab(hour="13", minute="30")
    },
    # Задача send_email будет запускаться каждый воскресенье в 8:30
    "daily": {
        "task": "schedul.send_email",
        "schedule": crontab(day_of_week="0", hour="8", minute="30")
    }
}
