# import pika

# # tls-рукопожатие
# connection = pika.BlockingConnection(
#     pika.ConnectionParameters(host="localhost")
# )

# # виртуальные каналы
# channel = connection.channel()

# # Очередь
# channel.queue_declare(queue="main", durable=True)

# channel.basic_qos(prefetch_count=1)
# # QoS - quality of servise

# # ch - channel - информация о канал передачи
# # method - информация о самой передаче
# # properties - информация о сообщение
# # body - само сообщение

# def func_call(ch, method, properties, body):
#     print(f"{body.decode()}")

#     # ch.basic_ack(delivery_tag=method.delivery_tag) - подтверждение
#     # ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False) - отказ с удалением
#     # ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True) - отказ с вовзратом в очередь

# # Публикация
# channel.basic_consume(
#     queue="main",
#     on_message_callback=func_call,
#     auto_ack=False
# )

# channel.start_consuming()



import pika
import re

# tls-рукопожатие
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

# виртуальные каналы
channel = connection.channel()

# Очередь
channel.queue_declare(queue="main", durable=True)

channel.basic_qos(prefetch_count=1)
# QoS - quality of service — только 1 сообщение за раз

# ch - channel - информация о канале передачи
# method - информация о самой передаче
# properties - информация о сообщении
# body - само сообщение

def func_call(ch, method, properties, body):
    text = body.decode()
    print(f"[Consumer 2] Получено: {text}")

    # Парсим поле status
    match = re.search(r"Status:\s*(\w+)", text)
    status = match.group(1) if match else ""

    if status == "error":
        # Удаляем сообщение
        print(f"[Consumer 2] Status=error → удаляем")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
    else:
        # Сохраняем в файл
        with open("output.txt", "a", encoding="utf-8") as f:
            f.write(text + "\n")
        print(f"[Consumer 2] Status={status} → сохранено в output.txt")
        ch.basic_ack(delivery_tag=method.delivery_tag)

# Подписка
channel.basic_consume(
    queue="main",
    on_message_callback=func_call,
)

print("[Consumer 2] Ожидание сообщений...")
channel.start_consuming()
