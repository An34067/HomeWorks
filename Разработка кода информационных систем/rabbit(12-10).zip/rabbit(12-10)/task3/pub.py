# import pika

# # tls-рукопожатие
# connection = pika.BlockingConnection(
#     pika.ConnectionParameters(host="localhost")
# )

# # виртуальные каналы
# channel = connection.channel()

# # Очередь
# channel.queue_declare(queue="main", durable=True)

# # Публикация
# channel.basic_publish(
#     exchange="", # Способ передачи -> прямой (Direct) 
#     routing_key="hello", # Название очереди куда передаем
#     body="Event: register. User: A. D. Status: error" # Само сообщение
# )

# connection.close()


import pika

# tls-рукопожатие
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

# виртуальные каналы
channel = connection.channel()

# Очередь
channel.queue_declare(queue="main", durable=True)

# Параметры сообщения: Event, User (инициалы), Status
messages = [
    "Event: register. User: AB. Status: success",
    "Event: login. User: AB. Status: success",
    "Event: logout. User: AB. Status: error",
    "Event: register. User: AB. Status: error",
    "Event: purchase. User: AB. Status: success",
    "Event: delete. User: AB. Status: error",
]

for msg in messages:
    channel.basic_publish(
        exchange="",
        routing_key="main",
        body=msg.encode("utf-8"),
        properties=pika.BasicProperties(delivery_mode=2)  # persistent
    )
    print(f"[Producer] Отправлено: {msg}")

connection.close()