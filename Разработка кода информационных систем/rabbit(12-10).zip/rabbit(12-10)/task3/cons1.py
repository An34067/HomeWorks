# import pika

# # tls-рукопожатие
# connection = pika.BlockingConnection(
#     pika.ConnectionParameters(host="localhost")
# )

# # виртуальные каналы
# channel = connection.channel()

# # Очередь
# channel.queue_declare(queue="main", durable=True)

# channel.basic_qos(prefetch_count=1)
# # QoS - quality of servise

# # ch - channel - информация о канал передачи
# # method - информация о самой передаче
# # properties - информация о сообщение
# # body - само сообщение

# def func_call(ch, method, properties, body):
#     print(f"{body.decode()}")

#     if 'event' == 'register':
#         ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

#     # ch.basic_ack(delivery_tag=method.delivery_tag) - подтверждение
#     # ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False) - отказ с удалением
#     # ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True) - отказ с вовзратом в очередь

# # Публикация
# channel.basic_consume(
#     queue="main",
#     on_message_callback=func_call
# )

# channel.start_consuming()



import pika
import re

# tls-рукопожатие
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

# виртуальные каналы
channel = connection.channel()

# Очередь
channel.queue_declare(queue="main", durable=True)

channel.basic_qos(prefetch_count=1)
# QoS - quality of service — только 1 сообщение за раз

# ch - channel - информация о канале передачи
# method - информация о самой передаче
# properties - информация о сообщении
# body - само сообщение

def func_call(ch, method, properties, body):
    text = body.decode()
    print(f"[Consumer 1] Получено: {text}")

    # Парсим поле event
    match = re.search(r"Event:\s*(\w+)", text)
    event = match.group(1) if match else ""

    if event == "register":
        # Возвращаем в очередь
        print(f"[Consumer 1] Event=register → возвращаем в очередь")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
    else:
        # Выводим в терминал
        print(f"[Consumer 1] Event={event} → обработано, вывод в терминал")
        ch.basic_ack(delivery_tag=method.delivery_tag)

# Подписка
channel.basic_consume(
    queue="main",
    on_message_callback=func_call,
)

print("[Consumer 1] Ожидание сообщений...")
channel.start_consuming()
