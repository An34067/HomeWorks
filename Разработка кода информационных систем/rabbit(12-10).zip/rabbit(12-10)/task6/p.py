from task6.consumer import send_email, cost_value

email = send_email.delay(567)
cost = cost_value.delay(5, 2)

email_res = email.get()
cost_res = cost.get()

print("Send_email выполнен:",  email_res)
print("Cost_value выполнен:",  cost_res)
