from celery import Celery
import time

app = Celery(
    "celery_app",
    broker="amqp://guest:guest@localhost//",
    backend="db+sqlite:///result.sqlite3"

)

@app.task
def send_email(user_id: int) -> str:
    time.sleep(2)
    return f"email отправлен {user_id}"

@app.task
def cost_value(cost: int, value: int) -> str:
    time.sleep(3)
    return cost * value
    
    













# /// - относительный путь(тек. лерриктории)
# //// - абсолютный путь
