import pyotp
import qrcode
#Password pip install pyotp qrcode[pil]

def create_totp(mail):
    secret = pyotp.random_base32()
    totp = pyotp.TOTP(secret)

    uri = totp.provisioning_uri(
        name="MyApp",
        issuer_name="mail"
    )

    img = qrcode.make(uri)
    img.save("qr-code.png")

    return secret

secret = create_totp("patdesathonor6@gmail.com")
print(secret)



#OTP - одноразовые пароли (6-и символов)

#TOTP - Timed OTP and HOTP
# секретный ключ (sha256, rsa...)
# текущее время х секретный ключ -> 412748 
# Условие: синхронизация по времени

# HOTP - по счетчику
# начальное состояние: 0
# Нажатие кнопки, переход на страницу, ... -> +1
# счетчик х секретный ключ -> 412748 
#
#