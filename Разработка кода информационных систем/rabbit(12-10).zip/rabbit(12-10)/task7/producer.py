from task6.consumer import send_email, cost_value

friend_email = "jonona056@gmail.com"

send_email.delay("jonona056@gmail.com", "Тема 1", "Письмо 1")
print("mail 1 send")
send_email.delay("jonona056@gmail.com", "Тема 2", "Письмо 2")
print("mail 2 send")
send_email.delay("jonona056@gmail.com", "Тема 3", "Письмо 3")
print("mail 3 send")
print("Done!")    
