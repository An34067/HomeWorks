import pyotp

def verify(secret, user_code):
    totp = pyotp.TOTP(secret)
    result = totp.verify(user_code)
    return result

    
secret = "7EP56BHSJYEXQP22XPLODGQU73FYSY5F"

user_code = input()

if verify(secret, user_code):
    print("Code is correct")
else:
    print("Error!!!")
