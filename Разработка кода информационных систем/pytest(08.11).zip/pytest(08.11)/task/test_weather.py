import pytest
from unittest.mock import AsyncMock, patch
from weather import read_timtable

@pytest.mark.asyncio
async def test_read_timtable_sunny():
    with patch("weather.main", new_callable=AsyncMock, return_value={"weather": "sunny"}):
        result = await read_timtable()
        assert result is True