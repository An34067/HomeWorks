import pytest

@pytest.mark.asyncio
async def test_connection_is_open(connection):
    assert connection.is_open is True