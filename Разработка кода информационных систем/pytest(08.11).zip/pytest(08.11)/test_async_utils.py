import pytest
from async_utils import hello, person
from unittest.mock import AsyncMock, patch


@pytest.mark.asyncio
async def test_hello():
    result = await hello()
    assert result == "hello"


@pytest.mark.asyncio
async def test_person():
    with patch("async_utils.hello", new_callable=AsyncMock, return_value="hello"):
        response = await person()
    assert response == "hello Oleg"
