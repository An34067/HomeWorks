import asyncio


async def hello():
    await asyncio.sleep(1)
    return "hello"


async def person():
    response = await hello()
    return response + "Oleg"
