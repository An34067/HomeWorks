import logging
import loguru
import sys
from loguru import logger

logger.remove()

logger.add(
    "log/lesson.log",
    rotation="10 MB",
    retention="14 days",
    encoding="UTF-8"
)

logger.add(
    sys.stderr,
    level="INFO",
    format="{level} {time} {message}"
)

def dfd(email):
    log = logger.bind(email=email)
    log.add(
        sys.stderr,
        format="{level} {time} {message} по почте {extra[email]}"
    )
    log.debug("Test")
    log.info("Info")
    log.warning("Warning")
    
logger.error("Error")
logger.critical("Critical error")
dfd("example")











#stdout
#echo "Hello" > text.txt

#stderr
#echo "Hello" > text.txt

#logging.DEBUG
#logging.INFO
#logging.WARNING
#logging.ERROR
#logging.CRITICAL


# logging.basicConfig(
#     level=logging.WARNING,
#     format="%(levelname)s at %(asctime)s %(filename)s %(lineno)s %(message)s"
# )

# def divide(x, y):
#     logging.debug(f"Начата работа с аргументами {x} {y}")
#     try:
#         logging.debug(f"Пытаемся посчитать это")
#         return x/y
#     except ZeroDivisionError as exc:
#         logging.error("Пытаетесь поделить на ноль!!!")

# divide(1, 0)






# logging.warning("ПРЕДУПРЕЖДЕНИЕ!")




