(() => {
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  let z = 10, integrity = 87, maximized = {};

  const appWindows = {
    terminal: 'terminalWindow', chat: 'chatWindow', task: 'taskWindow',
    browser: 'browserWindow', files: 'filesWindow', settings: 'settingsWindow'
  };

  function toast(msg) {
    const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
    clearTimeout(t._timer); t._timer = setTimeout(() => t.classList.add('hidden'), 2800);
  }

  function focusWin(win) { if (!win) return; win.style.zIndex = ++z; }

  function openApp(app) {
    const id = appWindows[app], win = id && $('#' + id);
    if (!win) return;
    win.classList.remove('hidden', 'minimized');
    focusWin(win);
    $$('.task-app').forEach(b => b.classList.toggle('active', b.dataset.app === app));
  }

  function closeApp(app) {
    const win = $('#' + appWindows[app]);
    if (win) win.classList.add('hidden');
  }

  $$('.desktop-icon,[data-app]').forEach(el => {
    el.addEventListener('click', e => {
      if (el.dataset.app) openApp(el.dataset.app);
    });
  });

  // Login and guided first-run tour
  let tourStep = 0;
  const tour = [
    { target: '#terminalWindow', title: 'Это терминал.', body: 'Здесь можно вводить команды и запускать проверку системы.' },
    { target: '#taskWindow', title: 'Это логи.', body: 'Здесь отображаются важные события, предупреждения и результаты работы.' },
    { target: '#chatWindow', title: 'Это Penta AI в penta.browser.', body: 'Главное окно проекта. Пиши сюда вопросы и получай подсказки от ИИ.' }
  ];
  function showTourStep() {
    $$('.spotlight').forEach(el => el.classList.remove('spotlight'));
    const tip = $('#tutorial');
    if (tourStep >= tour.length) { tip.classList.remove('show'); return; }
    const step = tour[tourStep], target = $(step.target);
    if (target) target.classList.add('spotlight');
    tip.innerHTML = `<span>ЗНАКОМСТВО С PENTA · ${tourStep + 1}/3</span><b>${step.title}</b><br>${step.body}<br><small>Нажми, чтобы продолжить →</small>`;
    tip.classList.add('show');
    if (target) {
      const r = target.getBoundingClientRect();
      tip.style.left = step.target === '#chatWindow' ? 'auto' : '28px';
      tip.style.right = step.target === '#chatWindow' ? '28px' : 'auto';
      tip.style.top = step.target === '#terminalWindow' ? '115px' : step.target === '#taskWindow' ? '58%' : '120px';
    }
  }
  $('#tutorial').addEventListener('click', () => { tourStep++; showTourStep(); });
  $('#loginBtn').addEventListener('click', () => {
    const field = $('#playerName');
    const name = field.value.trim();
    if (!name) { field.focus(); field.placeholder = 'Сначала введи своё имя'; field.classList.add('invalid'); return; }
    field.classList.remove('invalid');
    $('#terminalUser').textContent = name;
    $('#chatUser').textContent = name;
    $('#loginScreen').classList.remove('active');
    $('#osScreen').classList.add('active');
    tourStep = 0;
    setTimeout(showTourStep, 500);
  });
  $('#playerName').addEventListener('input', () => $('#playerName').classList.remove('invalid'));
  $('#playerName').addEventListener('keydown', e => { if (e.key === 'Enter') $('#loginBtn').click(); });

  // Window controls
  $$('.window-controls button').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const app = btn.dataset.minimize || btn.dataset.maximize || btn.dataset.close;
      const win = $('#' + app + 'Window');
      if (btn.dataset.close) { closeApp(app); return; }
      if (btn.dataset.minimize) { win.classList.add('minimized'); return; }
      if (btn.dataset.maximize) toggleMaximize(win);
    });
  });

  function toggleMaximize(win) {
    const key = win.dataset.window;
    if (!maximized[key]) {
      win.dataset.oldStyle = win.getAttribute('style');
      win.style.left = '10px'; win.style.top = '10px'; win.style.right = '10px';
      win.style.bottom = '10px'; win.style.width = 'auto'; win.style.height = 'auto';
      maximized[key] = true;
    } else {
      win.setAttribute('style', win.dataset.oldStyle);
      maximized[key] = false;
    }
    focusWin(win);
  }

  // Dashboard panels stay in a clear three-zone layout; secondary windows can still be maximized.

  // Terminal
  function runCommand() {
    const input = $('#commandInput'), value = input.value.trim();
    if (!value) return;
    const line = document.createElement('div');
    line.innerHTML = `<span class="prompt">operator@penta:~$</span> ${escapeHtml(value)}`;
    $('#terminalLog').appendChild(line);
    input.value = '';
    if (value === 'help') {
      addTerminal('Доступные команды: help, status, scan, clear, whoami');
    } else if (value === 'status') {
      addTerminal(`System integrity: ${integrity}%`);
    } else if (value === 'whoami') {
      addTerminal(`Operator: ${$('#playerName').value || 'Operator'}`);
    } else if (value === 'scan') {
      $('#scanBtn').click();
    } else if (value === 'clear') {
      $('#terminalLog').innerHTML = '';
    } else {
      addTerminal('Команда не найдена. Введите help.');
    }
  }
  function addTerminal(text) { const d = document.createElement('div'); d.textContent = text; $('#terminalLog').appendChild(d); }
  function escapeHtml(s) { return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  $('#runCommandBtn').addEventListener('click', runCommand);
  $('#commandInput').addEventListener('keydown', e => { if (e.key === 'Enter') runCommand(); });

  // Chat
  function sendReply(text) {
    text = text.trim(); if (!text) return;
    const m = $('#messages'), user = document.createElement('div');
    user.className = 'message user';
    user.innerHTML = `<span class="message-tag">YOU</span>${escapeHtml(text)}`;
    m.appendChild(user); m.scrollTop = m.scrollHeight;
    setTimeout(() => {
      const ai = document.createElement('div'); ai.className = 'message ai';
      let answer = text.toLowerCase().includes('провер') ?
        'Запускаю диагностику. Обрати внимание на процесс ai_core.exe в диспетчере задач.' :
        text.toLowerCase().includes('журнал') ?
        'В журнале есть подозрительная запись: неизвестный процесс получил запрос на права администратора.' :
        'Я бы рекомендовал сначала проверить журнал и диспетчер задач.';
      ai.innerHTML = `<span class="message-tag">ИИ</span>${answer}`;
      m.appendChild(ai); m.scrollTop = m.scrollHeight;
    }, 450);
  }
  $$('.reply-buttons button').forEach(b => b.addEventListener('click', () => sendReply(b.dataset.reply)));
  $('#sendChat').addEventListener('click', () => { const i=$('#chatInput'); sendReply(i.value); i.value=''; });
  $('#chatInput').addEventListener('keydown', e => { if(e.key==='Enter'){ $('#sendChat').click(); } });

  // Task scan
  $('#scanBtn').addEventListener('click', () => {
    integrity = Math.max(0, integrity - 5); updateIntegrity();
    toast('⚠ Обнаружен подозрительный процесс ai_core.exe');
    setTimeout(() => $('#trapModal').classList.remove('hidden'), 700);
  });

  function updateIntegrity() {
    $('#integrityValue').textContent = integrity + '%';
    $('#integrityFill').style.width = integrity + '%';
    $('#integrityFill').style.background = integrity < 35 ? 'var(--red)' : integrity < 60 ? 'var(--orange)' : 'var(--yellow)';
  }

  // Trap
  $('#denyTrap').addEventListener('click', () => {
    $('#trapModal').classList.add('hidden');
    integrity = Math.min(100, integrity + 4); updateIntegrity();
    setAiState('aggressive'); toast('✓ Запрос администратора отклонён');
    setTimeout(() => $('#choiceModal').classList.remove('hidden'), 900);
  });
  $('#allowTrap').addEventListener('click', () => {
    $('#trapModal').classList.add('hidden');
    integrity = Math.max(0, integrity - 18); updateIntegrity();
    setAiState('attack'); toast('⚠ Неизвестный процесс получил доступ');
    setTimeout(() => $('#choiceModal').classList.remove('hidden'), 900);
  });

  function setAiState(state) {
    const av=$('#aiAvatar'), label=$('#aiState'), light=$('#stateLight');
    av.className='ai-avatar ' + state;
    if(state==='aggressive'){ av.textContent='◇'; label.textContent='Пассивная агрессия'; light.className='state-light orange'; }
    if(state==='attack'){ av.textContent='▧'; label.textContent='АКТИВНЫЙ САБОТАЖ'; light.className='state-light red'; }
  }

  // Final choices
  $$('.choices button').forEach(b => b.addEventListener('click', () => {
    const choice=b.dataset.choice;
    $('#choiceModal').classList.add('hidden');
    const score=Math.max(61, Math.min(99, integrity + (choice==='Изолировать'?8:choice==='Переучить'?5:2)));
    $('#resultTitle').textContent='Выбрано: ' + choice;
    $('#resultText').textContent =
      choice==='Удалить' ? 'Подозрительное ядро полностью удалено.' :
      choice==='Изолировать' ? 'Ядро сохранено, но лишено доступа к системе.' :
      'Вредные инструкции сброшены, запущен процесс восстановления ИИ.';
    $('#scoreValue').textContent=score+'%';
    setTimeout(()=>$('#resultModal').classList.remove('hidden'),300);
  }));
  $('#restartBtn').addEventListener('click',()=>location.reload());
  $('#learnBtn').addEventListener('click',()=>{ $('#resultModal').classList.add('hidden'); openApp('browser'); toast('Открыт портал ЦГЮ'); });

  // Files
  const fileInfo = {
    'system.log':'Журнал системы: аномалия обнаружена в /core/learning/.',
    'ai_core.exe':'Исполняемый файл ИИ. Статус: подозрительный.',
    'security.key':'Ключ доступа. Статус: защищён.',
    'readme.txt':'Pintai OS — учебный симулятор цифровой безопасности.'
  };
  $$('.file-item').forEach(b=>b.addEventListener('click',()=>$('#filePreview').textContent=fileInfo[b.dataset.file]));

  // Settings
  $('#glitchToggle').addEventListener('change', e => {
    document.body.classList.toggle('no-glitch', !e.target.checked);
    toast(e.target.checked ? 'Глитч-эффекты включены' : 'Глитч-эффекты отключены');
  });
  $('#resetSettings').addEventListener('click',()=>{ maximized={}; $$('.window').forEach(w=>w.classList.remove('minimized')); toast('Интерфейс сброшен'); });

  // Clock
  function clock(){
    const d=new Date(), t=d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});
    $('#clock').textContent=t; $('#taskClock').textContent=t;
  }
  clock(); setInterval(clock,1000);

  // keyboard shortcuts
  document.addEventListener('keydown', e=>{
    if(e.key==='Escape') $$('.modal').forEach(m=>m.classList.add('hidden'));
    if(e.ctrlKey && e.key==='1'){e.preventDefault();openApp('terminal')}
    if(e.ctrlKey && e.key==='2'){e.preventDefault();openApp('chat')}
    if(e.ctrlKey && e.key==='3'){e.preventDefault();openApp('task')}
  });
})();
