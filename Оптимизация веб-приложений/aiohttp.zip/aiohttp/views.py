from django.shortcuts import render, aget_object_or_404
from django.http import HttpResponse
from django.views.generic import ListView


async def my_view(request):
    items = await aget_object_or_404(Product, pk=1)
    return render(...)

async def my_create_view(request):
    new_product = Product()
    ...
    await new_product.asave()