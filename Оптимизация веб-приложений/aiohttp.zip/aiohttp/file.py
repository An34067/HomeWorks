import asyncio
import aiohttp

async def get_num(session):
        async with session.get("https://matsyuk.site:2323") as responce:
            result = await responce.text()
            return int(result)

async def main():
    async with aiohttp.ClientSession() as session:
        result = await asyncio.gather(
            get_num(session),
            get_num(session),
            get_num(session)
        )
    
    print(sum(result))

asyncio.run(main())





















# from time import sleep, time
# from random import randint
# import asyncio

# async def fetch():
#     await asyncio.sleep(1)
#     return randint(0, 99)

# async def main():
#     start = time()
#     task_a = asyncio.create_task(fetch())
#     task_b = asyncio.create_task(fetch())
#     task_c = asyncio.create_task(fetch())

#     a, b, c = await asyncio.gather(task_a, task_b, task_c)

#     end = time()
#     print(f"Время выполнения: {end - start}")
#     print(a, b, c)
# asyncio.run(main())