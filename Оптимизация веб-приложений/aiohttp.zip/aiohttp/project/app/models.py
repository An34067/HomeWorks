from django.db import models

# Create your models here.

class Manufacturer(models.Model):
    name = models.CharField(max_length=150)
    country = models.CharField(max_length=150)

    class Meta:
        verbose_name = "Производитель"
        verbose_name_prular = "Производители"

    def __str__(self):
        return self.name    

class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    manufacturer = models.ForeignKey(Manufacturer, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Товар"
        verbose_name_prular = "Товары"

    def __str__(self):
        return self.name    