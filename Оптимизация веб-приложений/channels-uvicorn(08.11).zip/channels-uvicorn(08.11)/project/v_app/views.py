from django.shortcuts import render
from django.http import HttpResponse

def start_page(request):
    if request.method == 'POST':
        seconds = request.POST.get('seconds')
        return HttpResponse(f"<script>window.location.href='/?seconds={seconds}';</script>")
    return render(request, 'start.html')

def index(request):
    return render(request, 'index.html')