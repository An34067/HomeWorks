import asyncio
import json
from channels.generic.websocket import AsyncWebsocketConsumer

class TimerConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.channel_layer.group_add('timer_group', self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard('timer_group', self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        if data.get('action') == 'start':
            seconds = int(data.get('seconds', 10))
            asyncio.create_task(self.run_timer(seconds))

    async def run_timer(self, seconds):
        for i in range(seconds, -1, -1):
            await self.channel_layer.group_send(
                'timer_group',
                {
                    'type': 'timer_update',
                    'time_left': i
                }
            )
            await asyncio.sleep(1)

    async def timer_update(self, event):
        await self.send(text_data=str(event['time_left']))
