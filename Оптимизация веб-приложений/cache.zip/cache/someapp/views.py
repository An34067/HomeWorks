from django.shortcuts import render
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_control, never_cache
from django.views.generic import TemplateView
# Create your views here.


@cache_control(
        max_age=60*60*6,
        public=True
)
def page1(request):
    return render(request, 'page1.html')


@cache_control(
        max_age=60*60*24
)
def page2(request):
    return render(request, 'page2.html')


@cache_control(
        max_age=60*60*24*7
)
def page3(request):
    return render(request, 'page3.html')


@never_cache
def page4(request):
    return render(request, 'page4.html')


@method_decorator(cache_control(max_age=60*60*24*7), 'dispatch')
class page5(TemplateView):
    template_name = 'page5.html'
    