from channels.generic.websocket import WebsocketConsumer, AsyncWebsocketConsumer

class EchoConsumer(AsyncWebsocketConsumer):
    async def connect(self) -> None:
        await self.channel_layer.group_add(
            'broadcast_messages',
            self.channel_name
        )
        return await self.accept()

    async def disconnect(self, code: int):
        await self.channel_layer.group_discard(
            'broadcast_messages',
            self.channel_name
        )
        return await super().disconnect(code)

    async def receive(self, text_data = None, bytes_data = None):
        await self.send(f"Сервер получил: {text_data}")