import asyncio

from django.http import JsonResponse
from django.shortcuts import render
from channels.layers import get_channel_layer

# Create your views here.

def main(request):
    return render(request, 'index.html')

def start_page(request):
    return render(request, 'start.html')

def start_timer(request):
    if request.method == 'POST':
        seconds = int(request.POST.get('seconds', 10))
        asyncio.create_task(run_timer(seconds))
        return JsonResponse({"status": "started"})
    return JsonResponse({"status": "error"}, status=400)

async def run_timer(seconds):
    layer = get_channel_layer()

    for i in range(seconds, -1, -1):
        'broadcast_messages',
        {
            'type': 'message.broadcast',
            'text': str(i)
        }
        await asyncio.sleep(1)