from channels.generic.websocket import WebsocketConsumer

class EchoWebsocketConsumer(WebsocketConsumer):
    def websocket_connect(self):
        return self.accept()
        #return self.close()

    def receive(self, text_data = None, bytes_data = None):
        return self.send(text_data)

    