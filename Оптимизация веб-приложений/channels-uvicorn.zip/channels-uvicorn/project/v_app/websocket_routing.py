from channels.routing import URLRouter
from django.urls import path
from .consumers import *

router = URLRouter(
    [
        path('ws/echo', EchoConsumer.as_asgi())
    ]
)