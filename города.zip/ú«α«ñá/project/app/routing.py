from django.urls import re_path
from app import consumer

websocket_urlpatterns = [
    re_path(r'ws/game/$', consumer.CityGameConsumer.as_asgi())
]