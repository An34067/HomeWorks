from django.shortcuts import render
from django.views import View
from django.http import JsonResponse
from .models import *
from django.shortcuts import get_object_or_404


# Create your views here.


class MyView(View):
    def get(self, request):
        obj = get_object_or_404(Item, pk=1)
        # obj = Item.objects.all()
        obj = {
            'data': obj
        }
        return JsonResponse(obj)









































# from django.http import HttpResponse, HttpRequest
# from .models import *
# def json_view(request: HttpRequest) -> HttpResponse:
# #     return HttpResponse("""
# # {
# #     "status": "ok",
# #     "data" {
# #         "value1": 123,
# #         "value2": 6.5
# #     }
# # }
# # """, content_type='application/json')
#     items = Item.objects.all()
#     return render(request,
#                   'template.json',
#                   {'items': items},
#                   content_type='application/json')

