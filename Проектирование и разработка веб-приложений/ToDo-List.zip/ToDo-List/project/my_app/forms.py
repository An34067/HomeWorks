from django.forms import ModelForm
from .models import *

class TaskFrom(ModelForm):
    model = Task
    fields = ['title', 'description', 'is_done', 'performer_id', 'tags']

class TagFrom(ModelForm):
    model = Tag
    fields = ['name']

    