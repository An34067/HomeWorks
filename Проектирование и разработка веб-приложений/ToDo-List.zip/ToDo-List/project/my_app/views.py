from django.shortcuts import render
from django.http import JsonResponse
from django.views import View
from django.shortcuts import get_object_or_404
from .models import Task, Tag
# Create your views here.

# GET /tasks/ — все задачи
class TaskListView(View):
    def get(self, request):
        tasks = Task.objects.all()
        data = [
            {
                'id': t.id,
                'title': t.title,
                'description': t.description,
                'is_done': t.is_done,
                'assignee': t.assignee.username if t.assignee else None,
                'tags': [tag.name for tag in t.tags.all()],
            }
            for t in tasks
        ]
        return JsonResponse({'data': data}, safe=False)


# GET /tasks/<id>/ — одна задача
class TaskDetailView(View):
    def get(self, request, pk):
        obj = get_object_or_404(Task, pk=pk)
        data = {
            'id': obj.id,
            'title': obj.title,
            'description': obj.description,
            'is_done': obj.is_done,
            'assignee': obj.assignee.username if obj.assignee else None,
            'tags': [tag.name for tag in obj.tags.all()],
        }
        return JsonResponse({'data': data})


# GET /tasks/undone/ — невыполненные задачи
class UndoneTaskListView(View):
    def get(self, request):
        tasks = Task.objects.filter(is_done=False)
        data = [
            {
                'id': t.id,
                'title': t.title,
                'is_done': t.is_done,
            }
            for t in tasks
        ]
        return JsonResponse({'data': data}, safe=False)


# GET /tasks/by-tag/<tag_id>/ — задачи по тегу
class TasksByTagView(View):
    def get(self, request, tag_id):
        tag = get_object_or_404(Tag, pk=tag_id)
        tasks = tag.tasks.all()
        data = [
            {
                'id': t.id,
                'title': t.title,
                'is_done': t.is_done,
            }
            for t in tasks
        ]
        return JsonResponse({'tag': tag.name, 'data': data})


# GET /tags/ — все теги
class TagListView(View):
    def get(self, request):
        tags = Tag.objects.all()
        data = [{'id': t.id, 'name': t.name} for t in tags]
        return JsonResponse({'data': data}, safe=False)


# GET /tags/<id>/ — один тег
class TagDetailView(View):
    def get(self, request, pk):
        tag = get_object_or_404(Tag, pk=pk)
        data = {'id': tag.id, 'name': tag.name}
        return JsonResponse({'data': data})