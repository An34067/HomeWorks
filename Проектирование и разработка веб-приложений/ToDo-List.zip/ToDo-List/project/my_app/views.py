from django.shortcuts import render
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views import View
from .models import *

# Create your views here.

class TaskListView(View):
    def get(self, request):
        tasks = Task.objects.all()
        task_list = []
        for task in tasks:
            task_list.append(
                {
                    'id': task.id,
                    'title': task.title,
                    'description': task.description,
                    'is_done': task.is_done,
                    'performer_id': task.performer_id.username if task.performer_id else None,
                })
            obj = {
                'data': task_list
            }
            return JsonResponse(obj)

class TagListView(View):
    def get(self, request):
        tags = Tag.objects.all()
        tag_list = []
        for tag in tags:
            tag_list.append({
                'id': tag.id,
                'name': tag.name,
            })
            obj = {
                'data': tag_list
            }
            return JsonResponse(obj)