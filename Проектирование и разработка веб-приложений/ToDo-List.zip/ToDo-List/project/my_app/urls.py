from django.urls import path

from .views import *

urlpatterns = [
    path('tasks/', TaskListView.as_view()),
    path('tags/', TagListView.as_view()),
]